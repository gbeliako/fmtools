# Testing various functions in pyfmtools
#
#
################################################################## section 4.2 #################################################################

from  pyfmtools import ffi, lib
import numpy as np
import math


#  initialisation 
env=ffi.new("struct fm_env *")
n=3
lib.py_fm_init(n,  env);


# # Testing functions section 4.2

# fm.py_Choquet(x, v, env)
x=np.array([0.2,0.5,0.4],np.float)
px = ffi.cast("double *", x.ctypes.data)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_Choquet example')
r1=lib.py_Choquet(px, pv, env)
print(r1)


# fm.py_ChoquetMob(x, Mob, env)
x=np.array([0.2,0.5,0.4],np.float)
px = ffi.cast("double *", x.ctypes.data)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
print('lib.py_ChoquetMob example')
r2=lib.py_ChoquetMob(px, pmob, env)
print(r2)


# fm.py_ChoquetKinter(x,  v,  kint, env)
x=np.array([0.2,0.5,0.4],np.float)
px = ffi.cast("double *", x.ctypes.data)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)


kint=2
print('lib.py_ChoquetKinter example')
r=lib.py_ChoquetKinter(px,  pv,kint, env )
print(r)


# fm.py_Sugeno(x, v, env)
x=np.array([0.2,0.5,0.4],np.float)
px = ffi.cast("double *", x.ctypes.data)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_Sugeno example')
r1=lib.py_Sugeno(px, pv, env)
print(r1)


# fm.py_Orness(v, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_Orness example')
print(lib.py_Orness(pv, env))


# fm.py_Entropy(v, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_Entropy example')
print(lib.py_Entropy(pv, env))


# fm.py_Mobius(v, mob, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_Mobius example')
mob=np.zeros(env.m, np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
lib.py_Mobius(pv,pmob,env)
print(mob)


# fm.py_Zeta(pmob, pv, env)
v=np.zeros(env.m, np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_Zeta example')
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
lib.py_Zeta(pmob, pv, env)
print(v)


#fm.py_Shapley(v, s, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
s=np.zeros(env.n,np.float)
ps = ffi.cast("double *", s.ctypes.data)
print('lib.py_Shapley example')
lib.py_Shapley(pv,ps,env)
print(s)


#fm.py_ShapleyMob(Mob, S, env)
print('lib.py_ShapleyMob example')
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
s=np.zeros(env.n, np.float)
ps = ffi.cast("double *", s.ctypes.data)
lib.py_ShapleyMob(pmob,ps,env)
print(s)


# fm.py_Banzhaf(pv, B, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
B=np.zeros(env.n, np.float)
pB = ffi.cast("double *", B.ctypes.data)
print('lib.py_Banzhaf example')
lib.py_Banzhaf(pv, pB, env)
print(B)


# fm.py_BanzhafMob(pmob, B, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
B=np.zeros(env.n, np.float)
pB = ffi.cast("double *", B.ctypes.data)
print('lib.py_BanzhafMob example')
lib.py_BanzhafMob(pmob, pB, env)
print(B)


# fm.py_Interaction(v, s, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
s=np.zeros(env.m,np.float)
ps = ffi.cast("double *", s.ctypes.data)
print('lib.py_Interaction example')
lib.py_Interaction(pv, ps, env)
print(s)


# fm.py_InteractionMob(Mob, s, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
s=np.zeros(env.m, np.float)
ps = ffi.cast("double *", s.ctypes.data)
print('lib.py_InteractionMob example')
lib.py_InteractionMob(pmob, ps, env)
print(s)


# fm.py_InteractionB(v, b, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
b=np.zeros(env.m, np.float)
pb = ffi.cast("double *", b.ctypes.data)
print('lib.py_InteractionB example')
lib.py_InteractionB(pv, pb, env)
print(b)


# fm.py_InteractionBMob(Mob, b, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
b=np.zeros(env.m, np.float)
pb = ffi.cast("double *", b.ctypes.data)
print('lib.py_InteractionBMob example')
lib.py_InteractionBMob(pmob, pb, env)
print(b)


# fm.py_BipartitionShapleyIndex(v, s, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
s=np.zeros(env.m, np.float)
ps = ffi.cast("double *", s.ctypes.data)
print('lib.py_BipartitionShapleyIndex example')
lib.py_BipartitionShapleyIndex(pv,ps,env)
print(s)


# fm.py_BipartitionBanzhafIndex(v, b, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
b=np.zeros(env.m, np.float)
pb = ffi.cast("double *", b.ctypes.data)
print('lib.py_BipartitionBanzhafIndex example')
lib.py_BipartitionBanzhafIndex(pv,pb,env)
print(b)


# fm.py_NonadditivityIndex(v, na, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
na=np.zeros(env.m, np.float)
pna = ffi.cast("double *", na.ctypes.data)
print('lib.py_NonadditivityIndex')
lib.py_NonadditivityIndex(pv,pna,env)
print(na)


# fm.py_BNonadditivityIndexMob(Mob, na, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
na=np.zeros(env.m, np.float)
pna = ffi.cast("double *", na.ctypes.data)
print('lib.py_BNonadditivityIndexMob')
lib.py_BNonadditivityIndexMob(pmob,pna,env)
print(na)


# fm.py_NonmodularityIndex(pv, pnm, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
nm=np.zeros(env.m, np.float)
pnm = ffi.cast("double *", nm.ctypes.data)
print('lib.py_NonmodularityIndex')
lib.py_NonmodularityIndex(pv, pnm, env)
print(nm)


# fm.py_NonmodularityIndexMob(pmob, pnm, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
nm=np.zeros(env.m, np.float)
pnm = ffi.cast("double *", nm.ctypes.data)
print('lib.py_NonmodularityIndexMob')
lib.py_NonmodularityIndexMob(pmob, pnm, env)
print(nm)


# fm.py_NonmodularityIndexMobkadditive(pmob, pnm, k, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
nm=np.zeros(env.m, np.float)
pnm = ffi.cast("double *", nm.ctypes.data)
k=2
print('lib.py_NonmodularityIndexMobkadditive')
lib.py_NonmodularityIndexMobkadditive(pmob, pnm, k, env)
print(nm)


# fm.py_NonmodularityIndexKinteractive(pv, pnm, kint, length, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
nm=np.zeros(env.m, np.float)
pnm = ffi.cast("double *", nm.ctypes.data)
kint=2
print('lib.py_NonmodularityIndexKinteractive')
lib.py_NonmodularityIndexKinteractive(pv, pnm,kint, env)
print(nm)


# fm.py_dualm(v, d, env)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
d=np.zeros(env.m, np.float)
pd = ffi.cast("double *", d.ctypes.data)

print('lib.py_dualm')
lib.py_dualm(pv, pd, env)
print(d)


# fm.py_dualmMob(Mob, d, env)
mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
d=np.zeros(env.m, np.float)
pd = ffi.cast("double *", d.ctypes.data)
print('lib.py_dualmMob')
lib.py_dualmMob(pmob, pd, env)
print(d)


# fm.py_ConstructLambdaMeasure(singletons, lambda, v, env)
lambd=np.array([0.0],np.float)
plambd=ffi.cast("double *", lambd.ctypes.data)
singletons=np.array([0, 0.3, 0.5],np.float)
psingletons = ffi.cast("double *", singletons.ctypes.data)
v=np.zeros(env.m, np.float)
pv = ffi.cast("double *", v.ctypes.data)
lib.py_ConstructLambdaMeasure(psingletons, plambd, pv, env)
print('lib.py_ConstructLambdaMeasure')
print(lambd)
print(v)


# fm.py\_ConstructLambdaMeasureMob(singletons, lambda, Mob, env)
lambd=np.array([0.0],np.float)
plambd=ffi.cast("double *", lambd.ctypes.data)
singletons=np.array([0, 0.3, 0.5],np.float)
psingletons = ffi.cast("double *", singletons.ctypes.data)
mob=np.zeros(env.m, np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
print('lib.py_ConstructLambdaMeasureMob')
lib.py_ConstructLambdaMeasureMob(psingletons, plambd, pmob, env)
print(lambd)
print(mob)

# fm.py_export_maximal_chains(n, v, mc, env)
n=3
vb=np.array([0, 0.00224734, 0.06493396, 0.51092037, 0.00965497, 0.37405545, 0.15455057, 1],np.float)
pvb = ffi.cast("double *", vb.ctypes.data)
mc=np.zeros(math.factorial(n)*n,np.float)
pmc = ffi.cast("double *", mc.ctypes.data)
print('lib.py_export_maximal_chains')
lib.py_export_maximal_chains(n,pvb,pmc,env)
print(mc)


# fm.py_ConvertCard2Bit(dest, src, env)
print('lib.py_ConvertCard2Bit(pvb,pvc, env)')
src=np.array([0, 0.0340916, 0.00890771, 0.01109779, 0.07918582, 0.6305862, 0.1846705, 1],np.float)
psrc = ffi.cast("double *", src.ctypes.data)
dest=np.zeros(env.m,np.float)
pdest = ffi.cast("double *", dest.ctypes.data)
lib.py_ConvertCard2Bit(pdest,psrc, env)
print(dest)


# fm.pyminsubset and fm.pymaxsubset
# S in binary form
x=np.array([0,0.3,0.5,0.6,0.7,0.8,0.85,0.9],np.float)
px = ffi.cast("double *", x.ctypes.data)
print('lib.py_min_subset(px,n,S)')
print(lib.py_min_subset(px,3,6))

print('lib.py_max_subset(px,n,S)')    
print(lib.py_max_subset(px,3,5))


# py_min_subsetC and py_max_subsetNegC
# S in binary form
x=np.array([0,0.3,0.5],np.float)
px = ffi.cast("double *", x.ctypes.data)

print('lib.py_min_subsetC(px,n,S,env)')
print(lib.py_min_subsetC(px,3,3,env))

print('lib.py_max_subsetNegC(px,n,S,env)')
print(lib.py_max_subsetNegC(px,3,3,env))


# other functions
print('lib.py_SizeArraykinteractive(n,k,env)') 
print(lib.py_SizeArraykinteractive(3,1,env))

print('lib.py_IsSubsetC(i, j, env)')
print(lib.py_IsSubsetC(2,1,env))

print('lib.py_IsElementC(A, j, env)')
print(lib.py_IsElementC(1,2,env))

print('lib.py_fm_arraysize( n, kint, env)')
print(lib.py_fm_arraysize(3,1,env))



# fm.py_ExpandKinteractive2Bit(dest, src, env, kint, arraysize)
#src=np.array([0, 0.0340916, 0.00890771, 0.01109779, 0.07918582, 0.6305862, 0.1846705, 1])
src=np.array([0.0340916,  0.01109779, 0.07918582,0.7,1],np.float)
psrc = ffi.cast("double *", src.ctypes.data)
kint=1
arraysize=lib.py_SizeArraykinteractive(n, kint, env)
dest=np.zeros(env.m, np.float)
pdest = ffi.cast("double *", dest.ctypes.data)
lib.py_ExpandKinteractive2Bit(pdest,psrc,env,kint,arraysize)
dest


# fm.py_ExpandKinteractive2Bit_m(dest, src, env, kint, arraysize, VVC)
#src=np.array([0, 0.0340916, 0.00890771, 0.01109779, 0.07918582, 0.6305862, 0.1846705, 1])
src=np.array([0.0340916,  0.01109779, 0.07918582,0.7,1],np.float)
psrc = ffi.cast("double *", src.ctypes.data)
dest=np.zeros(env.m,np.float)
pdest = ffi.cast("double *", dest.ctypes.data)
kint=1
arraysize=lib.py_SizeArraykinteractive(n, kint, env)
vcc=np.zeros(env.m, np.float)
pvcc = ffi.cast("double *", vcc.ctypes.data)

lib.py_ExpandKinteractive2Bit_m(pdest,psrc,env,kint,arraysize,pvcc)
print(dest)



# fm.py_ShowCoalitions(A, env)
A=np.zeros( 2**n, np.intc)
pA = ffi.cast("int *", A.ctypes.data)
print('lib.py_ShowCoalitions(pA,env)')
lib.py_ShowCoalitions(pA,env)
print(A)



mob=np.array([0.0,0.3,0.5,-0.2,0.4,0.1,-0.2,0.1],np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
v=np.array([0,0.3,0.5,0.6,0.4,0.8,0.7,1],np.float)
pv = ffi.cast("double *", v.ctypes.data)
print('lib.py_IsMeasureAdditive(pv, env)')
print(lib.py_IsMeasureAdditive(pv, env))

print('lib.py_IsMeasureAdditiveMob(pmob, env)')
print(lib.py_IsMeasureAdditiveMob(pmob, env))

print('lib.py_IsMeasureAdditiveMob(pmob, env)')
print(lib.py_IsMeasureAdditiveMob(pmob, env))

print('lib.py_IsMeasureBalanced(pv, env)')
print(lib.py_IsMeasureBalanced(pv, env))

print('lib.py_IsMeasureBalancedMob(pmob, env)')
print(lib.py_IsMeasureBalancedMob(pmob, env))

print('lib.py_IsMeasureSelfdual(pv, env)')
print(lib.py_IsMeasureSelfdual(pv, env))

print('lib.py_IsMeasureSelfdualMob(pmob, env)')
print(lib.py_IsMeasureSelfdualMob(pmob, env))

print('lib.py_IsMeasureSubadditive(pv, env)')
print(lib.py_IsMeasureSubadditive(pv, env))

print('lib.py_IsMeasureSubadditiveMob(pmob, env)')
print(lib.py_IsMeasureSubadditiveMob(pmob, env))

print('lib.py_IsMeasureSubmodular(pv, env)')
print(lib.py_IsMeasureSubmodular(pv, env))

print('lib.py_IsMeasureSubmodularMob(pmob, env)')
print(lib.py_IsMeasureSubmodularMob(pmob, env))

print('lib.py_IsMeasureSuperadditive(pv, env)')     
print(lib.py_IsMeasureSuperadditive(pv, env))

print('lib.py_IsMeasureSuperadditiveMob(pmob, env)')
print(lib.py_IsMeasureSuperadditiveMob(pmob, env))

print('lib.py_IsMeasureSupermodular(pv, env)')
print(lib.py_IsMeasureSupermodular(pv, env))

print('lib.py_IsMeasureSupermodularMob(pmob, env)')
print(lib.py_IsMeasureSupermodularMob(pmob, env))

print('lib.py_IsMeasureSymmetricMob(pmob, env)')
print(lib.py_IsMeasureSymmetricMob(pmob, env))

print('lib.py_IsMeasureKMaxitive(pv, env)')
print(lib.py_IsMeasureKMaxitive(pv, env))

print('lib.py_IsMeasureKMaxitiveMob(pmob, env)')
print(lib.py_IsMeasureKMaxitiveMob(pmob, env))




################################################################## section 4.3 #################################################################





# section 1 ###################################################################################################


print('Section 4.3 ')

envsp=ffi.new("struct fm_env_sparse *")



# testing lib.py_prepare_fm_sparse(n, tup, ptuples, envsp)
n=3
tup=0
tuples=np.zeros( 1, np.intc)
ptuples = ffi.cast("int *", tuples.ctypes.data)
lib.py_prepare_fm_sparse(n, tup, ptuples, envsp)



# adding singletons: testing py_add_singletons_sparse
v=np.array([0.1,0.2,0.3],np.float)
pv = ffi.cast("double *", v.ctypes.data)
lib.py_add_singletons_sparse(pv,envsp)


# testing pairs
# fm.pyaddpairsparse(i, j, v, envsp)
lib.py_add_pair_sparse(1, 2, 0.4, envsp)
lib.py_add_pair_sparse(1, 3, 0.5, envsp)
lib.py_add_pair_sparse(2, 3, 0.6, envsp) # it is working



#v1=np.array([0,0,0,0,0,0], dtype='f')
v1=np.array([0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],np.float)
pv1 = ffi.cast("double *", v1.ctypes.data)



# testing: fm.pyexpand2addfull(v, envsp)
lib.py_expand_2add_full(pv1, envsp)
print(v1)



# testing lib.py_Shapley2addMob(pv1, pb,n) and lib.py_ShapleyMob_sparse(psv,  n,   envsp) 
#      when env sparse only have singletons and pairs
b=np.zeros(3, np.float)
pb = ffi.cast("double *", b.ctypes.data)
lib.py_Shapley2addMob(pv1, pb,n)
print(b)
sv=np.zeros(3, np.float)
psv = ffi.cast("double *", sv.ctypes.data)
lib.py_ShapleyMob_sparse(psv,  n,   envsp)
print(sv)



# testing tuples
# fm.pyaddtuplesparse(tupsize, tuple, v, envsp)
tup1=np.array([1,2,3],np.intc)
ptup1 = ffi.cast("int *", tup1.ctypes.data)
lib.py_add_tuple_sparse(3, ptup1, 0.7, envsp)



#v2=np.array([0,0,0,0,0,0,0,0], dtype='f')
v2=np.array([0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0],np.float)
pv2 = ffi.cast("double *", v2.ctypes.data)


# fm.pyexpandsparsefull(v, envsp)
lib.py_expand_sparse_full(pv2, envsp)
print(v2)



# fm.pysparsegetsingletons(n, v, envsp)
s=np.zeros(n, np.float)
ps = ffi.cast("double *", s.ctypes.data)
lib.py_sparse_get_singletons(n, ps,envsp)
print(s)


# fm.pysparsegetpairs(pairs, v, envsp)
pairs=np.zeros(32,np.intc)
ppairs = ffi.cast("int *", pairs.ctypes.data)
vals=np.zeros(32, np.float)
pvals = ffi.cast("double *", vals.ctypes.data)
sizepairs= lib.py_sparse_get_pairs(ppairs, pvals,envsp)
print(sizepairs)
print(pairs)
print(vals)



# fm.pysparsegettuples(tuples, v, envsp)
indextuples=np.zeros(32,np.intc)
pindextuples = ffi.cast("int *", indextuples.ctypes.data)
vvt=np.zeros(32, np.float)
pvvt = ffi.cast("double *", vvt.ctypes.data)
sizetuples = lib.py_sparse_get_tuples(pindextuples, pvvt,envsp)
print(sizetuples)
print(indextuples)
print(vvt)

print('End Sec 1')

# section 2 ###################################################################################################
# using the same env sparse structure defined above to test other functions


# testing 
#    py_tuple_cardinality_sparse
#    lib.py_get_num_tuples
#    py_get_sizearray_tuples

print(lib.py_tuple_cardinality_sparse(0,envsp))
print(lib.py_get_num_tuples(envsp))
print(lib.py_get_sizearray_tuples(envsp))

# fm.pyisinsetsparse(A, card, i, envsp)
card=3
lib.py_is_inset_sparse(0, card, 2, envsp)

# fm.pyissubsetsparse(A, cardA, B, cardB, envsp)
lib.py_is_subset_sparse(0, 3, 1, 2, envsp)

#fm.py_min_subset_sparse(x, n, S, cardS, envsp)
x=np.array([0.1,0.05,0.2],np.float)
px = ffi.cast("double *", x.ctypes.data)
print(lib.py_min_subset_sparse(px, 3, 0, 3, envsp))

#fm.py_max_subset_sparse(x, n, S, cardS, envsp)
print(lib.py_max_subset_sparse(px, 3, 0, 3, envsp))

# fm.pyChoquetMobsparse(x, n, envsp)
x=np.array([0.1,0.05,0.2])
px = ffi.cast("double *", x.ctypes.data)
n=3

print(lib.py_ChoquetMob_sparse(px, n, envsp))

# fm.pyShapleyMobsparse(v, n, envsp)
v=np.zeros(3, np.float)
n=3
pv = ffi.cast("double *", v.ctypes.data)
lib.py_ShapleyMob_sparse(pv, n, envsp)
print(v)
print('sparsemob')

# fm.pyBanzhafMobsparse(v, n, envsp)
v_1=np.zeros(3,np.float)
pv_1 = ffi.cast("double *", v_1.ctypes.data)
lib.py_BanzhafMob_sparse(pv_1, n, envsp)
print(v_1)


# fm.pyNonmodularityindexsparse(w, n, envsp)
w_1=np.zeros(8, np.float)
pw_1 = ffi.cast("double *", w_1.ctypes.data)
lib.py_Nonmodularityindex_sparse(pw_1, n, envsp) # 
print(w_1)

# section 3 ###################################################################################################

# defining another env sparse structure to check the function: py_populate_fm_2add_sparse

envsp_1=ffi.new("struct fm_env_sparse *")

# fm.pypopulatefm2addsparse(singletons, numpairs, pairs, indicesp1, indicesp2,envsp)

singletons=np.array([0.1,0.2,0.3])
psingletons = ffi.cast("double *", singletons.ctypes.data)
numpairs=3
pairs = np.array([0.4,0.5,0.6])
ppairs = ffi.cast("double *", pairs.ctypes.data)
indicesp1 = np.array([1,1,2], np.intc)
pindicesp1 = ffi.cast("int *", indicesp1.ctypes.data)
indicesp2 = np.array([2,3,3], np.intc)
pindicesp2 = ffi.cast("int *", indicesp2.ctypes.data)

#prepare empty structure
lib.py_prepare_fm_sparse(3, 0 , pindicesp1 , envsp_1)


lib.py_populate_fm_2add_sparse(psingletons, numpairs, ppairs, pindicesp1, pindicesp2,envsp_1)
print('popuate 2add sparse ')

# expand singletons ans pair in a vector
v3=np.array([0.0,0.0,0.0,0.0,0.0,0.0])
pv3 = ffi.cast("double *", v3.ctypes.data)
lib.py_expand_2add_full(pv3, envsp_1)
print(v3)


# getting singletons from env sparse stru
v2=np.array([0.0,0.0,0.0,0.0,0.0,0.0])
pv2 = ffi.cast("double *", v2.ctypes.data)
lib.py_sparse_get_singletons(3, pv2, envsp_1)
print(v2)


# getting indexes and values of pairs from env sparse stru
v4=np.array([0.0,0.0,0.0,0.0,0.0,0.0])
pv4 = ffi.cast("double *", v4.ctypes.data)
pairs=np.array([0,0,0,0,0,0,0,0],np.intc)
ppairs=ffi.cast("int *", pairs.ctypes.data)
lib.py_sparse_get_pairs(ppairs, pv4, envsp_1)
print('pairs')
print(v4)
print(pairs)



# section 4 ###################################################################################################


# definig another env sparse structuret to test if the function
#      lib.py_generate_fm_2additive_convex_withsomeindependent generates the vector v3, which will be used to populate..
#           the env sparse structure with singletons ans pairs

envsp_2=ffi.new("struct fm_env_sparse *")

# testing lib.py_populate_fm_2add_sparse_from2add(n, pv3, envsp_2) and
#      lib.py_generate_fm_2additive_convex_withsomeindependent(1, n, pv3) 
print('random sparse')
n=3
v3=np.zeros(8,np.float)
pv3 = ffi.cast("double *", v3.ctypes.data)
lib.py_generate_fm_2additive_convex_withsomeindependent(1, n, pv3)
print(v3)

lib.py_prepare_fm_sparse(n, 0 , pindicesp1 , envsp_2) #needed to set pointers

lib.py_populate_fm_2add_sparse_from2add(n, pv3, envsp_2)


# getting singletons from env sparse stru
v2=np.zeros(3,np.float)
pv2 = ffi.cast("double *", v2.ctypes.data)
lib.py_sparse_get_singletons(3, pv2, envsp_2)
print(v2)

# getting indexes and values of pairs from env sparse stru
v4=np.zeros(6,np.float)
pv4 = ffi.cast("double *", v4.ctypes.data)
pairs=np.array([0,0,0,0,0,0,0,0,0,0],np.intc)
ppairs=ffi.cast("int *", pairs.ctypes.data)
lib.py_sparse_get_pairs(ppairs, pv4, envsp_2)
print(v4)
print(pairs)


# expand singletons ans pair in a vector
v3=np.array([0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])
pv3 = ffi.cast("double *", v3.ctypes.data)
lib.py_expand_2add_full(pv3, envsp_2)
print(v3)



lib.py_free_fm_sparse(envsp_2)
lib.py_free_fm_sparse(envsp_1)
lib.py_free_fm_sparse(envsp)
# section 5 ###################################################################################################


# other functions - envsp is no longer needed

# testing py_generate_fm_2additive_convex(1, n, pv) and
#     py_dualMobKadd(n, lengthv, k, pv, pd, env) functions

print('other functions')

k=2
n=20
env=ffi.new("struct fm_env *")
sz=lib.py_fm_arraysize(n,k,env)
v=np.zeros( n*n, float)
pv = ffi.cast("double *", v.ctypes.data)
d=np.zeros( n*n, float)
pd = ffi.cast("double *", d.ctypes.data)
lengthv=lib.py_generate_fm_2additive_convex(1, n, pv)
lib.py_dualMobKadd(n, lengthv, k, pv, pd, env)

print('Shapley and Banzhaf for n=',n)
# testing py_Shapley2addMob(pv,ps,n) and py_Banzhaf2addMob(pv,pb,n)
s=np.zeros( n, float)
ps = ffi.cast("double *", s.ctypes.data)
b=np.zeros( n, float)
pb = ffi.cast("double *", b.ctypes.data)
lib.py_Shapley2addMob(pv,ps,n)
lib.py_Banzhaf2addMob(pv,pb,n)
print(s)
print(b)


# testing fm.py_Choquet2addMob(x, v, n)
x=np.array([0.2,0.5,0.4,0.6,0.2,0.5,0.4,0.6,0.2,0.5,0.4,0.6,0.2,0.5,0.4,0.6,0.2,0.5,0.4,0.6])
px = ffi.cast("double *", x.ctypes.data)
print('lib.py_Choquet example')
r1=lib.py_Choquet2addMob(px, pv, 3)
print(r1)


# testing :fm.pyOWA( x, w, n)
#          fm.pyWAM( x, w, n)
n=3
x=np.array([0.2,0.5,0.4])
px = ffi.cast("double *", x.ctypes.data)
lib.py_fm_init(n,  env);
w=np.array([0.3,0.3,0.4])
pw = ffi.cast("double *", w.ctypes.data)

print('OWA,WAM')
r2=lib.py_OWA(n, px, pw) # 
print(r2)
r3=lib.py_WAM(n, px, pw) #
print(r3)


# section 6 ###################################################################################################


# definig another env sparse structure
# generating fm 2additive and kadditive by using:
#     py_generate_fm_2additive_convex_sparse(n,  env_sp)
#     lib.py_generate_fm_kadditive_convex_sparse(n, k, nonzero, env_sp)

env_sp=ffi.new("struct fm_env_sparse *")
n=5


# using lib.py_prepare_fm_sparse
tup=0
tuples=np.zeros( 0, np.intc)
ptuples = ffi.cast("int *", tuples.ctypes.data)
lib.py_prepare_fm_sparse(n, tup, ptuples, env_sp)

# py_generate_fm_2additive_convex_sparse(n,  env_sp) 
lib.py_generate_fm_2additive_convex_sparse(n,  env_sp)

# testing lib.py_generate_fm_kadditive_convex_sparse(n, k, nonzero, env_sp)
k=4
lib.py_generate_fm_kadditive_convex_sparse(n, k, 10, env_sp);
k=3
lib.py_generate_fm_kadditive_convex_sparse(n, k, 5, env_sp);


# testing lib.py_ShapleyMob_sparse( pb,  n,   env_sp)
b=np.zeros(n,np.float)
pb = ffi.cast("double *", b.ctypes.data)
lib.py_ShapleyMob_sparse( pb,  n,   env_sp)
print(b)


# getting singleston
s=np.zeros(n,np.float)
ps = ffi.cast("double *", s.ctypes.data)
lib.py_sparse_get_singletons(n, ps,env_sp)
print(s)

# getting pairs from ens sparse structure
pairs=np.zeros(20,np.intc)
ppairs = ffi.cast("int *", pairs.ctypes.data)
vals=np.zeros(20)
pvals = ffi.cast("double *", vals.ctypes.data)
sizepairs= lib.py_sparse_get_pairs(ppairs, pvals,env_sp)
print(sizepairs)
print(pairs)
print(vals)

# testing lib.py_get_num_tuples(env_sp) and lib.py_get_sizearray_tuples(env_sp)
numbertuples=lib.py_get_num_tuples(env_sp)
print(numbertuples)
sizetuplearray=lib.py_get_sizearray_tuples(env_sp)
print(sizetuplearray)



# # getting tuples from ens sparse structure
indextuples=np.zeros(sizetuplearray,np.intc)
pindextuples = ffi.cast("int *", indextuples.ctypes.data)
vvt=np.zeros(numbertuples,np.float)
pvvt = ffi.cast("double *", vvt.ctypes.data)
sizetuples = lib.py_sparse_get_tuples(pindextuples, pvvt,env_sp)
print(sizetuples)
print(indextuples)
print(vvt)


lib.py_fm_free( env);

################################################################## section 4.4 - 4.5 #################################################################



# # Testing functions section 4.4
print('FM fitting routines')

env=ffi.new("struct fm_env *")
n=3
lib.py_fm_init(n,  env);


datanum=10
kadditive=2
v=np.zeros(2**n,np.float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)


lib.py_FuzzyMeasureFit(datanum, kadditive, env, pv, pdataset)
print(v)



datanum=10
kadditive=3
mob=np.zeros(2**n,np.float)
pmob = ffi.cast("double *", mob.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)


lib.py_FuzzyMeasureFitMob(datanum, kadditive, env, pmob, pdataset)
print(mob)


# ## py_FuzzyMeasureFitLP

datanum=10
additive=2
v=np.array([0.0,0,0,0,0,0,0,0],float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)

options=np.array([0],np.intc)
poptions= ffi.cast("int *", options.ctypes.data)

indexlow = np.array([0,0,0],np.float)
pindexlow = ffi.cast("double *", indexlow.ctypes.data)
indexhihg = np.array([1,1,1], np.float)
pindexhihg = ffi.cast("double *", indexhihg.ctypes.data)

#option1=0
option1=np.array([0],np.intc)
poption1= ffi.cast("int *", option1.ctypes.data)

orness = np.array([0.5],np.float)
porness = ffi.cast("double *", orness.ctypes.data)


lib.py_FuzzyMeasureFitLP(datanum, additive, env, pv, pdataset,  poptions, pindexlow, pindexhihg, poption1, porness)
print(v)

# ## py_FuzzyMeasureFitLPMob

# fm.py_FuzzyMeasureFitLPMob(datanum, additive, env, Mob, dataset,  options, indexlow, indexhihg, option1, orness)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset, int * options, double* indexlow,
#  double* indexhihg, int* option1, double* orness);

datanum=10
additive=2
mob=np.array([0,0,0,0,0,0,0,0],float)
pmob = ffi.cast("double *", mob.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)

options=np.array([0],np.intc)
poptions= ffi.cast("int *", options.ctypes.data)

indexlow = np.array([0,0,0],np.float)
pindexlow = ffi.cast("double *", indexlow.ctypes.data)
indexhihg = np.array([1,1,1],np.float)
pindexhihg = ffi.cast("double *", indexhihg.ctypes.data)

#option1=0
option1=np.array([0],np.intc)
poption1= ffi.cast("int *", option1.ctypes.data)

orness = np.array([0.5],np.float)
porness = ffi.cast("double *", orness.ctypes.data)

lib.py_FuzzyMeasureFitLPMob(datanum, additive, env, pmob, pdataset,  poptions, pindexlow, pindexhihg, poption1, porness)
print(mob)


# fm.py_FuzzyMeasureFitKtolerant(datanum, additive, env, v, dataset)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset);

datanum=10
additive=2
v=np.array([0,0,0,0,0,0,0,0],float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)


lib.py_FuzzyMeasureFitKtolerant(datanum, additive, env, pv, pdataset)
print(v)

print('k-maxitive')
# ## py_FuzzyMeasureFitLPKmaxitive
# fm.py_FuzzyMeasureFitLPKmaxitive(datanum, additive, env, v, dataset)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset);

datanum=10
additive=2
v=np.array([0,0,0,0,0,0,0,0],float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)

lib.py_FuzzyMeasureFitLPKmaxitive(datanum, additive, env, pv, pdataset)
print(v)

# ## py_fittingOWA

# fm.py_fittingOWA(datanum, env, v, dataset)
# (int datanum, struct fm_env* env, double* v, double* dataset);
n=3
datanum=10
v=np.array([0,0,0],float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)

lib.py_fittingOWA(datanum, env, pv, pdataset)
print(v)


# ## py_fittingWAM
# fm.py_fittingWAM(datanum, env, v, dataset)
# (int datanum, struct fm_env* env, double* v, double* dataset);

datanum=10
v=np.array([0,0,0],float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)

lib.py_fittingWAM(datanum, env, pv, pdataset)
print(v)

print('k-interactive')

# ## py_FuzzyMeasureFitLPKinteractive
# fm.py_FuzzyMeasureFitLPKinteractive(datanum, additive, env, v, dataset, K)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset, double* K);

datanum=10
additive = 2
v=np.zeros(2**n,np.float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)
K=np.array([0.5])
pK = ffi.cast("double *", K.ctypes.data)

lib.py_FuzzyMeasureFitLPKinteractive(datanum, additive, env, pv, pdataset, pK)
print(v)

# ## py_FuzzyMeasureFitLPKinteractiveAutoK

# fm.py\_FuzzyMeasureFitLPKinteractiveAutoK(datanum, additive, env, v, dataset, K, maxiters)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset, double* K, int* maxiters);

datanum=10
additive = 2
v=np.zeros(2**n,np.float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)
K=np.array([0.5])
pK = ffi.cast("double *", K.ctypes.data)
maxiters=np.array([100],np.intc)
pmaxiters = ffi.cast("int *", maxiters.ctypes.data)

lib.py_FuzzyMeasureFitLPKinteractiveAutoK(datanum, additive, env, pv, pdataset, pK, pmaxiters)
print(v)


# ## py_FuzzyMeasureFitLPKinteractiveMaxChains
# fm.py_FuzzyMeasureFitLPKinteractiveMaxChains(datanum, additive, env, v, dataset, K)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset, double* K);
print('maxchains')

datanum=10
additive = 2
v=np.zeros(2**n,np.float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)
K=np.array([0.5])
pK = ffi.cast("double *", K.ctypes.data)

lib.py_FuzzyMeasureFitLPKinteractiveMaxChains(datanum, additive, env, pv, pdataset, pK)
print(v)

# ## py_FuzzyMeasureFitLPKinteractiveMarginal
# fm.py_FuzzyMeasureFitLPKinteractiveMarginal(datanum, additive, env, v, dataset, K, submod)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset, double* K, int submod);
datanum=10
additive = 2
v=np.zeros(2**n,np.float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)
K=np.array([0.5])
pK = ffi.cast("double *", K.ctypes.data)
submod=1

lib.py_FuzzyMeasureFitLPKinteractiveMarginal(datanum, additive, env, pv, pdataset, pK, submod)
print(v)

# ## py_FuzzyMeasureFitLPKinteractiveMarginalMaxChain
# fm.py_FuzzyMeasureFitLPKinteractiveMarginalMaxChain(datanum, additive, env, v, dataset, K, maxiters, submod)
# (int datanum, int additive, struct fm_env* env, double* v, double* dataset, double* K, int* maxiters, int submod);

datanum=10
additive = 2
v=np.zeros(2**n,np.float)
pv = ffi.cast("double *", v.ctypes.data)
dataset=np.random.rand(datanum,n+1)
pdataset = ffi.cast("double *", dataset.ctypes.data)
K=np.array([0.5])
pK = ffi.cast("double *", K.ctypes.data)
maxiters=np.array([100],np.intc)
pmaxiters = ffi.cast("int *", maxiters.ctypes.data)
submod=1

lib.py_FuzzyMeasureFitLPKinteractiveMarginalMaxChain(datanum, additive, env, pv, pdataset, pK, pmaxiters, submod)
print(v)


# # Testing functions section 4.5
# testing fm.py_generate_fm_tsort(num, n, kint, markov, option, K, v, env) and 
# fm.py_generate_fm_minplus(num, n, kint, markov, option, K, v, env)
lib.py_fm_free( env);

print('sec 4.5')
num=10
n=6
kint=3
env=ffi.new("struct fm_env *")
lib.py_fm_init(n, env)
leng=lib.py_fm_arraysize(n, kint, env)
v=np.zeros(num * leng, float)
pv = ffi.cast("double *", v.ctypes.data)
lengthv=lib.py_generate_fm_tsort(num, n, kint, 1000, 0, 0.7, pv, env)

v1=np.zeros(num * leng, float)
pv1 = ffi.cast("double *", v1.ctypes.data)
lengthv1=lib.py_generate_fm_minplus(num, n, kint, 1000, 0, 0.7, pv1, env)
lib.py_fm_free( env);


# fm.py_generate_fm_convextsort(num, n, kint, markov, option, K, v, env)
num=1
n=5
env=ffi.new("struct fm_env *")
lib.py_fm_init(n, env)
leng=lib.py_fm_arraysize(n, n, env)
v=np.zeros(num * leng, float)
pv = ffi.cast("double *", v.ctypes.data)
lengthv=lib.py_generate_fmconvex_tsort(num, n, n, 1000, 0, 1, pv, env)
w=np.zeros(num * leng, float)
pw = ffi.cast("double *", w.ctypes.data)
lib.py_ConvertCard2Bit(pw, pv, env)
superm=lib.py_IsMeasureSupermodular(pw, env)
print('supermod')
print(superm)

# testing:
#   fm.py_generate_fm_2additive_convex(num, n, v)
#   fm.py_generate_fm_2additive_concave(num, n, v)
#   fm.py_generate_fm_2additive_convex_withsomeindependent(num, n, v)

num=10
n=5
v=np.zeros(num * n*n, np.float)
v1=np.zeros(num * n*n, np.float)
v2=np.zeros(num * n*n, np.float)
pv = ffi.cast("double *", v.ctypes.data)
pv1 = ffi.cast("double *", v1.ctypes.data)
pv2 = ffi.cast("double *", v2.ctypes.data)

lengthv=lib.py_generate_fm_2additive_convex(num, n, pv)
lengthv1=lib.py_generate_fm_2additive_concave(num, n, pv1)
lengthv2=lib.py_generate_fm_2additive_convex_withsomeindependent(num, n, pv2)
print(lengthv)
print(lengthv1)
print(lengthv2)

# testing
#   py_generate_fm_2additive_convex_sparse(n,  env_sp)
#   testing lib.py_generate_fm_kadditive_convex_sparse(n, k, nonzero, env_sp)
print('sparse convex')
env_sp=ffi.new("struct fm_env_sparse *")
n=5
tup=0
tuples=np.zeros( 0, np.intc)
ptuples = ffi.cast("int *", tuples.ctypes.data)
lib.py_prepare_fm_sparse(n, tup, ptuples, env_sp)

lib.py_generate_fm_2additive_convex_sparse(n,  env_sp)

k=4
lib.py_generate_fm_kadditive_convex_sparse(n, k, 10, env_sp)
k=3
lib.py_generate_fm_kadditive_convex_sparse(n, k, 5, env_sp)

# getting singleston
s=np.zeros(n,np.float)
ps = ffi.cast("double *", s.ctypes.data)
lib.py_sparse_get_singletons(n, ps,env_sp)
print(s)

# getting pairs from ens sparse structure
pairs=np.zeros(32,np.intc)
ppairs = ffi.cast("int *", pairs.ctypes.data)
vals=np.zeros(32,np.float)
pvals = ffi.cast("double *", vals.ctypes.data)
sizepairs= lib.py_sparse_get_pairs(ppairs, pvals,env_sp)
print(sizepairs)
print(pairs)
print(vals)

print('sparsetuples')
# # getting tuples from ens sparse structure
indextuples=np.zeros(32,np.intc)
pindextuples = ffi.cast("int *", indextuples.ctypes.data)
vvt=np.zeros(32,np.float)
pvvt = ffi.cast("double *", vvt.ctypes.data)
sizetuples = lib.py_sparse_get_tuples(pindextuples, pvvt,env_sp)
print(sizetuples)
print(indextuples)
print(vvt)

lib.py_fm_free( env);
lib.py_free_fm_sparse( env_sp);


