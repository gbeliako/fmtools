from  pyfmtools import ffi, lib as fm
import numpy as np
import math

print('This script provides some examples calling functions from pyfmtools.')
env=ffi.new("struct fm_env *")
n=3
fm.py_fm_init(n,  env);

x=np.array([0.2,0.5,0.4])
px = ffi.cast("double *", x.ctypes.data)
v=np.array([0.0,0.3,0.5,0.6,0.4,0.8,0.7,1.0])
pv = ffi.cast("double *", v.ctypes.data)

print('fm.py_Choquet example: Choquet integral wrt v')
r1=fm.py_Choquet(px, pv, env)
print(r1)

mob=np.zeros(env.m, np.double);
pmob = ffi.cast("double *", mob.ctypes.data)
fm.py_Mobius(pv,pmob,env)
print('fm.py_ChoquetMob example')
r2=fm.py_ChoquetMob(px, pmob, env)
print(r2)

print('fm.py_Sugeno example')
r1=fm.py_Sugeno(px, pv, env)
print(r1)

print('fm.py_Orness example')
print(fm.py_Orness(pv, env))

print('fm.py_Entropy example')
print(fm.py_Entropy(pv, env))

print('fm.py_Zeta example, back to standard representation')
fm.py_Zeta(pmob, pv, env)
print(v)


print('fm.py_Shapley example')
s=np.zeros(env.n, np.double)
ps = ffi.cast("double *", s.ctypes.data)

fm.py_Shapley(pv,ps,env)
print(s)
fm.py_ShapleyMob(pmob,ps,env)

print('fm.py_BanzhafMob example')
fm.py_BanzhafMob(pmob, ps, env)
print(s)

sm=np.zeros(env.m, np.double)
psm = ffi.cast("double *", sm.ctypes.data)
A=np.zeros(env.m, np.intc)
pA = ffi.cast("int *", A.ctypes.data)
fm.py_ShowCoalitions(pA, env)
print('fm.py_Interaction example: interaction indices representation')
fm.py_InteractionMob(pmob,psm,env)
print(sm)
print('in the binary ordering as follows')
print(A)


print('fm.py_NonadditivityIndex(pv,psm,env): nonadditivity indices')
fm.py_NonadditivityIndex(pv,psm,env)
print(sm)

print('fm.py_NonmodularityIndex(pv,psm,env): nonmodularity indices')
fm.py_NonmodularityIndex(pv,psm,env)
print(sm)

print('fm.py_ConstructLambdaMeasure(psingletons, plambd, pv, env)')
lambd=np.zeros(1, np.double)
plambd=ffi.cast("double *", lambd.ctypes.data)
singletons=np.array([0.0, 0.3, 0.5])
psingletons = ffi.cast("double *", singletons.ctypes.data)
v=np.zeros(env.m, np.double)
pv = ffi.cast("double *", v.ctypes.data)
fm.py_ConstructLambdaMeasure(psingletons, plambd, pv, env)
print(lambd)
print(v)

print('fm.py_NonmodularityIndex(pv,psm,env): nonmodularity indices')
fm.py_NonmodularityIndex(pv,psm,env)
print(sm)

print('Tests on additivity, sub/supermodularity  and symmetry')
print(fm.py_IsMeasureAdditive(pv, env), 'additive?')
print(fm.py_IsMeasureSubmodular(pv, env), 'submodular?')
print(fm.py_IsMeasureSupermodular(pv, env), 'supermodular?')
print(fm.py_IsMeasureSymmetric(pv, env), 'symmetric?')
print(fm.py_IsMeasureKMaxitive(pv, env), '-maxitive')

fm.py_fm_free( env);

